
@yield('css')

    <link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300;12..96,400;12..96,500;12..96,600;12..96,700&display=swap" rel="stylesheet" />

    <!-- Styles -->
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('kk/resources/pp/assets/css/swiper-bundle.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('kk/resources/pp/assets/css/venobox.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('kk/resources/pp/assets/css/style.css') }}" />
