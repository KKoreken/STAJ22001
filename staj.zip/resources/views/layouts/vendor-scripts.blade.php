<!-- JAVASCRIPT -->
<script src="{{asset('staj/public/build/libs/jquery/jquery.min.js') }}"></script>
<script src="{{asset('staj/public/build/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{asset('staj/public/build/libs/metismenu/metisMenu.min.js') }}"></script>
<script src="{{asset('staj/public/build/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{asset('staj/public/build/libs/node-waves/waves.min.js') }}"></script>
<!-- Icon -->
<script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>
@yield('scripts')
