@extends('layouts.master')
@section('title')
    Yönetici Paneli
@endsection
@section('page-title')
    Yönetici Paneli
@endsection
@section('body')

    <body data-sidebar="colored">
    @endsection
    @section('content')
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <form action="{{route('panel-project-update')}}" method="post" enctype="multipart/form-data">@csrf
                        <input type="hidden" name="id" value="{{$proje->id}}">
                    <div class="card-body">
                        <div class="d-flex mb-4 justify-content-between" >
                            <h5 class="card-title ">Proje Düzenle - Proje Adı</h5>
                            <button class="btn px-5 btn-primary">Onayla</button>
                        </div>
                        <div class="chat-leftsidebar me-4">
                            <div class="card mb-0">
                                <div class="chat-leftsidebar-nav">
                                    <ul class="nav nav-pills nav-justified bg-light-subtle" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <a href="#genelbilgi" data-bs-toggle="tab" aria-expanded="true" class="nav-link" aria-selected="false" role="tab" tabindex="-1">
                                                <i class="ri-message-2-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">Genel Bilgiler</span>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a href="#isler" data-bs-toggle="tab" aria-expanded="false" class="nav-link active" aria-selected="true" role="tab">
                                                <i class="ri-group-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">İşler</span>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a href="#contact" data-bs-toggle="tab" aria-expanded="false" class="nav-link" aria-selected="false" tabindex="-1" role="tab">
                                                <i class="ri-contacts-book-2-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">Dosyalar</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="tab-content pt-4">
                                <div class="tab-pane" id="genelbilgi" role="tabpanel">
                                    <div>
                                        <h5 class="font-size-14 mb-3">Genel Bilgiler</h5>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3">
                                                    <input value="{{$proje->baslik}}" type="text" class="form-control" name="baslik" id="baslik" placeholder="Enter Your First Name">
                                                    <label for="baslik">Proje Adı</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="Durumu">Proje Durumu</label>
                                                <select name="durum" class="form-select">
                                                    <option @if($proje->durum =='0' ) @endif  value="0">Pasif</option>
                                                    <option @if($proje->durum =='1') @endif  value="1">Devam Ediyor</option>
                                                    <option @if($proje->durum =='2' ) @endif  value="2">Tamamlandı</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane active show" id="isler" role="tabpanel">
                                    <h5 class="font-size-14 mb-2">İşler</h5>
                                    <div class="card-body">
                                        <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                            <tr>
                                                <th>İş Adı</th>
                                                <th>Başlangıç Tarihi</th>
                                                <th>Bitiş Tarihi</th>
                                                <th>Katılımcı</th>
                                                <th>Öncelik</th>
                                                <th>Durumu</th>
                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>İş Adı</td>
                                                <td>01.01.2020</td>
                                                <td>01.01.2020</td>
                                                <td>
                                                    <div class="avatar-group">
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-1.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-3.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <div class="avatar-xs">
                                                                            <span class="avatar-title rounded-circle bg-danger text-white font-size-16">
                                                                                3+
                                                                            </span>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="badge badge-soft-success font-size-12">Tamamlandı</span></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                            </button>
                                                        </a>

                                                        <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                            <a class="dropdown-item" href="#">İncele</a>
                                                            <a class="dropdown-item" href="{{route('panel-project-edit',['id'=>1])}}">Düzenle</a>
                                                            <div class="dropdown-divider"></div>
                                                            <a class="dropdown-item" href="#">Sil</a>
                                                        </div>
                                                    </div>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td>İş Adı</td>
                                                <td>01.01.2020</td>
                                                <td>01.01.2020</td>
                                                <td>
                                                    <div class="avatar-group">
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-1.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-3.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <div class="avatar-xs">
                                                                            <span class="avatar-title rounded-circle bg-danger text-white font-size-16">
                                                                                3+
                                                                            </span>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="badge badge-soft-info font-size-12">Devam Ediyor</span></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                            </button>
                                                        </a>

                                                        <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                            <a class="dropdown-item" href="#">Action</a>
                                                            <a class="dropdown-item" href="#">Another action</a>
                                                            <a class="dropdown-item" href="#">Something else here</a>
                                                            <div class="dropdown-divider"></div>
                                                            <a class="dropdown-item" href="#">Separated link</a>
                                                        </div>
                                                    </div>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-floating mb-3">
                                                                <input type="text" class="form-control" name="isadi" id="isadi" placeholder="İş Adı Giriniz.">
                                                                <label for="isadi">İş Adı</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <input class="form-control" type="date" name="baslangic_tarihi" id="example-date-input">
                                                </td>
                                                <td>
                                                    <input class="form-control" type="date" name="bitis_tarihi" id="example-date-input">
                                                </td>

                                                <td>
                                                    <span  style="width: 100%" class="badge badge-soft-info font-size-12">
                                                        <select multiple style="width: 100%" class="js-example-basic-single" name="kullanicilar[]">
                                                            <option selected value=""   >Kullanıcı Seçiniz</option>
                                                          <option value="AL">Kullanıcı 1</option>
                                                          <option value="AL">Kullanıcı 2</option>
                                                          <option value="AL">Kullanıcı 3</option>
                                                          <option value="WY">Ekip 1</option>
                                                          <option value="WY">Ekip 2</option>
                                                          <option value="WY">Ekip 3</option>
                                                        </select>
                                                    </span>
                                                </td>
                                                <td>
                                                    <select name="oncelik" class="form-select" aria-label="Default select example">
                                                        <option selected="">Öncelik Seçiniz</option>
                                                        <option style='background-color:#264653; color: white ' value="1">1</option>
                                                        <option style='background-color:#2a9d8f ' value="2">2</option>
                                                        <option style='background-color:#e9c46a ' value="3">3</option>
                                                        <option style='background-color:#f4a261 ' value="3">4</option>
                                                        <option style='background-color:#e76f51 ' value="3">5</option>
                                                    </select>
                                                </td>
                                                <td>
                                                </td>

                                            </tr>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>

                                <div class="tab-pane" id="contact" role="tabpanel">
                                    <h5 class="font-size-14 mb-2">Dosyalar</h5>

                                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                        <tr>
                                            <th>Dosya Adı</th>
                                            <th>Eklenme Tarihi</th>
                                            <th>İşlem</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><i class="mdi mdi-file-document font-size-16 align-middle text-primary me-2"></i> Dosya Adı</td>
                                            <td>01.01.2020</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a class="text-muted float-end dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <button type="button" class="btn btn-primary waves-effect waves-light">
                                                            İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                        </button>
                                                    </a>

                                                    <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                        <a class="dropdown-item" href="#">Indir</a>
                                                        <a class="dropdown-item" href="{{route('panel-project-edit',['id'=>1])}}">Düzenle</a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item" href="#">Sil</a>
                                                    </div>
                                                </div>
                                            </td>                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-floating mb-3">
                                                            <input name="dosyaadi" type="text" class="form-control" id="Dosyaadi" placeholder="Dosya Adı Giriniz.">
                                                            <label for="Dosyaadi">Dosya Adı</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td> Otomatik Atanır
                                            </td>
                                            <td>
                                                <input name="dosya" class="form-control" type="file">
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card body -->
                    </form>
                </div>
                <!-- end card -->
            </div>
            <!-- end col -->
        </div>
    @endsection
    @section('scripts')
        <!-- App js -->
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="{{ URL::asset('public/build/js/app.js') }}"></script>
        <script>
            $(document).ready(function() {
                $('.js-example-basic-single').select2();
            });
        </script>
@endsection
