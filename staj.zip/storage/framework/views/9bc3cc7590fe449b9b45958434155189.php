<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
<form action="<?php echo e(url('sube-ekle')); ?>" method="post"> <?php echo csrf_field(); ?>
    <select name="il_id" id="il">
        <?php $__currentLoopData = $il; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($i->id); ?>"><?php echo e($i->baslik); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    <select name="ilce_id" id="ilce"></select> <br>
    <input name="subeadi" placeholder="subeadi" type="text" > <br>
    <input name="longitude" placeholder="longitude" type="text" > <br>
    <input name="langtide" placeholder="langtide" type="text" > <br>
    <button type="submit">Onayla</button>
</form>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script >
    $('#il').change(function () {
        var il_id = $(this).val();
        $('#ilce').html('<option value="">İlçe Seçin</option>');
        if (il_id) {
            $.ajax({
                url: '/staj/ilceler/' + il_id,
                type: 'GET',
                success: function (data) {
                    $.each(data, function (index, ilce) {
                        $('#ilce').append('<option value="' + ilce.id + '">' + ilce.baslik + '</option>');
                    });
                }
            });
        }
    });

</script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\staj\resources\views/harita/subeekle.blade.php ENDPATH**/ ?>