<?php $__env->startSection('title'); ?>
    Anasayfa
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usertopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-select-bs4/css//select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Ticketlarım
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-4">Ticket ID : <?php echo e($ticket->uuid); ?></h4>
                        <form action="<?php echo e(route('edit-ticket-post')); ?>" method="post"> <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($ticket->id); ?>">
                        <div id="basic-pills-wizard" class="twitter-bs-wizard">
                            <ul class="twitter-bs-wizard-nav">
                                <li class="nav-item wizard-border">
                                    <a href="#seller-details" class="nav-link" data-toggle="tab">
                                        <span class="step-number">1. Genel Bilgiler</span>
                                    </a>
                                </li>
                                <li class="nav-item wizard-border">
                                    <a href="#company-document" class="nav-link" data-toggle="tab">
                                        <span class="step-number">2. Detaylı Bilgiler</span>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="#confirm-detail" class="nav-link" data-toggle="tab">
                                        <span class="step-number">3. Tamamla</span>
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content twitter-bs-wizard-tab-content">

                                <div class="tab-pane" id="seller-details">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="basicpill-firstname-input">Konu</label>
                                                    <input value="<?php echo e($ticket->title); ?>" name="title" type="text" class="form-control"
                                                           id="basicpill-firstname-input">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="category">Kategori</label>
                                                    <select class="form-control" name="category" id="category">
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if($ticket->categories[0]->id == $c->id ): ?> selected <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="labels">Etiket</label>
                                                    <select multiple class="form-control" name="labels[]" id="labels">
                                                        <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option <?php $__currentLoopData = $ticket->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($l->id == $c->id ): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                </div>
                                <div class="tab-pane" id="company-document">
                                    <div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="message">Mesaj</label>
                                                        <textarea  id="message" name="message" class="form-control" rows="2"><?php echo e($ticket->message); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="basicpill-companyuin-input">Öncelik</label>
                                                        <select class="form-control" name="priority" id="priority">
                                                            <option <?php if($ticket->priority=='1'): ?> selected <?php endif; ?> value="1">1</option>
                                                            <option <?php if($ticket->priority=='2'): ?> selected <?php endif; ?> value="2">2</option>
                                                            <option <?php if($ticket->priority=='3'): ?> selected <?php endif; ?> value="3">3</option>
                                                            <option <?php if($ticket->priority=='4'): ?> selected <?php endif; ?> value="4">4</option>
                                                            <option <?php if($ticket->priority=='5'): ?> selected <?php endif; ?> value="5">5</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="confirm-detail">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="text-center">
                                                <div class="mb-4">
                                                    <i class="mdi mdi-check-circle-outline text-success display-4"></i>
                                                </div>
                                                <div>
                                                    <h5>Ticket Güncellemesi Hazır</h5>
                                                    <button class="btn btn-primary" type="submit">Onayla</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                            <ul class="pager wizard twitter-bs-wizard-pager-link">
                                <li class="previous"><a href="javascript: void(0);">Geri</a></li>
                                <li class="next"><a href="javascript: void(0);">Ileri</a></li>
                            </ul>
                        </div>
                    </form>
                    </div>
                </div>
            </div>

        </div>
        <!-- end row -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- twitter-bootstrap-wizard js -->
        <script src="<?php echo e(URL::asset('public/build/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js')); ?>"></script>

        <script src="<?php echo e(URL::asset('public/build/libs/twitter-bootstrap-wizard/prettify.js')); ?>"></script>

        <!-- form wizard init -->
        <script src="<?php echo e(URL::asset('public/build/js/pages/form-wizard.init.js')); ?>"></script>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-without-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/user/ticket/edit.blade.php ENDPATH**/ ?>