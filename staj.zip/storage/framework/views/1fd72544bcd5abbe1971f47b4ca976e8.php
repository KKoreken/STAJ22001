<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex mb-4 justify-content-between" >
                            <h5 class="card-title ">Proje Düzenle - Proje Adı</h5>
                        </div>
                        <div class="chat-leftsidebar me-4">
                            <div class="card mb-0">
                                <div class="chat-leftsidebar-nav">
                                    <ul class="nav nav-pills nav-justified bg-light-subtle" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <a href="#isler" data-bs-toggle="tab" aria-expanded="false" class="nav-link active" aria-selected="true" role="tab">
                                                <i class="ri-message-2-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">İşler</span>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a href="#genelbilgi" data-bs-toggle="tab" aria-expanded="true" class="nav-link" aria-selected="false" role="tab" tabindex="-1">
                                                <i class="ri-group-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">Katılımcılar</span>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a href="#analiz" data-bs-toggle="tab" aria-expanded="true" class="nav-link" aria-selected="false" role="tab" tabindex="-1">
                                                <i class="ri-group-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">Analiz</span>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a href="#takvim" data-bs-toggle="tab" aria-expanded="true" class="nav-link" aria-selected="false" role="tab" tabindex="-1">
                                                <i class="ri-group-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">Takvim</span>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a href="#contact" data-bs-toggle="tab" aria-expanded="false" class="nav-link" aria-selected="false" tabindex="-1" role="tab">
                                                <i class="ri-contacts-book-2-line font-size-20"></i>
                                                <span class="mt-2 d-none d-sm-block">Dosyalar</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="tab-content pt-4">
                                <div class="tab-pane" id="genelbilgi" role="tabpanel">
                                    <div>
                                        <h5 class="font-size-14 mb-2">Katılımcılar</h5>
                                        <div class="card-body">
                                            <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                                                   style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                <thead>
                                                <tr>
                                                    <th>Ad Soyad</th>
                                                    <th>Başlangıç Tarihi</th>
                                                    <th>Toplam İş</th>
                                                    <th>Devam Eden İş</th>
                                                    <th>İşlem</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>Ad Soyad</td>
                                                    <td>01.01.2020</td>
                                                    <td>123</td>
                                                    <td>123</td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                    İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                                </button>
                                                            </a>

                                                            <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-details',['id'=>1])); ?>">İncele</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-edit',['id'=>1])); ?>">Düzenle</a>
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item" href="#">Sil</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ad Soyad</td>
                                                    <td>01.01.2020</td>
                                                    <td>123</td>
                                                    <td>123</td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                    İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                                </button>
                                                            </a>

                                                            <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-details',['id'=>1])); ?>">İncele</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-edit',['id'=>1])); ?>">Düzenle</a>
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item" href="#">Sil</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ad Soyad</td>
                                                    <td>01.01.2020</td>
                                                    <td>123</td>
                                                    <td>123</td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                    İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                                </button>
                                                            </a>

                                                            <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-details',['id'=>1])); ?>">İncele</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-edit',['id'=>1])); ?>">Düzenle</a>
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item" href="#">Sil</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ad Soyad</td>
                                                    <td>01.01.2020</td>
                                                    <td>123</td>
                                                    <td>123</td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                    İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                                </button>
                                                            </a>

                                                            <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-details',['id'=>1])); ?>">İncele</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-edit',['id'=>1])); ?>">Düzenle</a>
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item" href="#">Sil</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ad Soyad</td>
                                                    <td>01.01.2020</td>
                                                    <td>123</td>
                                                    <td>123</td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                    İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                                </button>
                                                            </a>

                                                            <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-details',['id'=>1])); ?>">İncele</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-edit',['id'=>1])); ?>">Düzenle</a>
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item" href="#">Sil</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ad Soyad</td>
                                                    <td>01.01.2020</td>
                                                    <td>123</td>
                                                    <td>123</td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <a class="text-muted dropdown-toggle font-size-20" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <button type="button" class="btn btn-primary waves-effect waves-light">
                                                                    İşlemler <i class="mdi mdi-dots-vertical"></i>
                                                                </button>
                                                            </a>

                                                            <div class="dropdown-menu dropdown-menu-end " style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate3d(-40px, 30px, 0px);" data-popper-placement="bottom-end">
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-details',['id'=>1])); ?>">İncele</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('panel-project-edit',['id'=>1])); ?>">Düzenle</a>
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item" href="#">Sil</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane active show" id="isler" role="tabpanel">
                                    <h5 class="font-size-14 mb-2">İşler</h5>
                                    <div class="card-body">
                                        <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                            <tr>
                                                <th>İş Adı</th>
                                                <th>Başlangıç Tarihi</th>
                                                <th>Bitiş Tarihi</th>
                                                <th>Katılımcı</th>
                                                <th>Öncelik</th>
                                                <th>Durumu</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>İş Adı</td>
                                                <td>01.01.2020</td>
                                                <td>01.01.2020</td>
                                                <td>
                                                    <div class="avatar-group">
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-1.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-3.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <div class="avatar-xs">
                                                                            <span class="avatar-title rounded-circle bg-danger text-white font-size-16">
                                                                                3+
                                                                            </span>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><div style="background-color:#2a9d8f; color: white;" class="w-75  text-center fa-1x py-1" >2</div></td>
                                                <td><span class="badge badge-soft-success font-size-12">Tamamlandı</span></td>
                                            </tr>
                                            <tr>
                                                <td>İş Adı</td>
                                                <td>01.01.2020</td>
                                                <td>01.01.2020</td>
                                                <td>
                                                    <div class="avatar-group">
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-1.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <img src="assets/images/users/avatar-3.jpg" alt="" class="rounded-circle avatar-xs">
                                                            </a>
                                                        </div>
                                                        <div class="avatar-group-item">
                                                            <a href="javascript: void(0);" class="d-inline-block">
                                                                <div class="avatar-xs">
                                                                            <span class="avatar-title rounded-circle bg-danger text-white font-size-16">
                                                                                3+
                                                                            </span>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><div style="background-color:#264653; color: white;" class="w-75  text-center fa-1x py-1" >1</div></td>
                                                <td><span class="badge badge-soft-info font-size-12">Devam Ediyor</span></td>
                                            </tr>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                                <div class="tab-pane" id="analiz" role="tabpanel">
                                    <div>
                                        <h5 class="font-size-14 mb-2">Analiz</h5>
                                        <div class="row">

                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="takvim" role="tabpanel">
                                    <div>
                                        <h5 class="font-size-14 mb-3">Genel Bilgiler</h5>
                                        <div class="row">
                                            <div class="col-xl-9">
                                                <div class="card mb-0">
                                                    <div class="card-body">
                                                        <div id="calendar" class="fc fc-media-screen fc-direction-ltr fc-theme-standard"><div class="fc-header-toolbar fc-toolbar fc-toolbar-ltr"><div class="fc-toolbar-chunk"><div class="fc-button-group"><button type="button" title="Previous week" aria-pressed="false" class="fc-prev-button fc-button fc-button-primary"><span class="fc-icon fc-icon-chevron-left"></span></button><button type="button" title="Next week" aria-pressed="false" class="fc-next-button fc-button fc-button-primary"><span class="fc-icon fc-icon-chevron-right"></span></button></div><button type="button" title="This week" disabled="" aria-pressed="false" class="fc-today-button fc-button fc-button-primary">today</button></div><div class="fc-toolbar-chunk"><h2 class="fc-toolbar-title" id="fc-dom-1">Jul 14 – 20, 2024</h2></div><div class="fc-toolbar-chunk"><div class="fc-button-group"><button type="button" title="month view" aria-pressed="false" class="fc-dayGridMonth-button fc-button fc-button-primary">month</button><button type="button" title="week view" aria-pressed="true" class="fc-timeGridWeek-button fc-button fc-button-primary fc-button-active">week</button><button type="button" title="day view" aria-pressed="false" class="fc-timeGridDay-button fc-button fc-button-primary">day</button></div></div></div><div aria-labelledby="fc-dom-1" class="fc-view-harness fc-view-harness-active" style="height: 533.333px;"><div class="fc-timeGridWeek-view fc-view fc-timegrid"><table role="grid" class="fc-scrollgrid  fc-scrollgrid-liquid"><thead role="rowgroup"><tr role="presentation" class="fc-scrollgrid-section fc-scrollgrid-section-header "><th role="presentation"><div class="fc-scroller-harness"><div class="fc-scroller" style="overflow: hidden scroll;"><table role="presentation" class="fc-col-header " style="width: 703px;"><colgroup><col style="width: 54px;"></colgroup><thead role="presentation"><tr role="row"><th aria-hidden="true" class="fc-timegrid-axis"><div class="fc-timegrid-axis-frame"></div></th><th role="columnheader" data-date="2024-07-14" class="fc-col-header-cell fc-day fc-day-sun fc-day-past"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 14, 2024" class="fc-col-header-cell-cushion">Sun 7/14</a></div></th><th role="columnheader" data-date="2024-07-15" class="fc-col-header-cell fc-day fc-day-mon fc-day-past"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 15, 2024" class="fc-col-header-cell-cushion">Mon 7/15</a></div></th><th role="columnheader" data-date="2024-07-16" class="fc-col-header-cell fc-day fc-day-tue fc-day-past"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 16, 2024" class="fc-col-header-cell-cushion">Tue 7/16</a></div></th><th role="columnheader" data-date="2024-07-17" class="fc-col-header-cell fc-day fc-day-wed fc-day-past"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 17, 2024" class="fc-col-header-cell-cushion">Wed 7/17</a></div></th><th role="columnheader" data-date="2024-07-18" class="fc-col-header-cell fc-day fc-day-thu fc-day-past"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 18, 2024" class="fc-col-header-cell-cushion">Thu 7/18</a></div></th><th role="columnheader" data-date="2024-07-19" class="fc-col-header-cell fc-day fc-day-fri fc-day-today"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 19, 2024" class="fc-col-header-cell-cushion">Fri 7/19</a></div></th><th role="columnheader" data-date="2024-07-20" class="fc-col-header-cell fc-day fc-day-sat fc-day-future"><div class="fc-scrollgrid-sync-inner"><a aria-label="July 20, 2024" class="fc-col-header-cell-cushion">Sat 7/20</a></div></th></tr></thead></table></div></div></th></tr></thead><tbody role="rowgroup"><tr role="presentation" class="fc-scrollgrid-section fc-scrollgrid-section-body "><td role="presentation"><div class="fc-scroller-harness"><div class="fc-scroller" style="overflow: hidden scroll;"><div class="fc-daygrid-body fc-daygrid-body-unbalanced fc-daygrid-body-natural" style="width: 703px;"><table role="presentation" class="fc-scrollgrid-sync-table" style="width: 703px;"><colgroup><col style="width: 54px;"></colgroup><tbody role="presentation"><tr role="row"><td aria-hidden="true" class="fc-timegrid-axis fc-scrollgrid-shrink"><div class="fc-timegrid-axis-frame fc-scrollgrid-shrink-frame  fc-timegrid-axis-frame-liquid"><span class="fc-timegrid-axis-cushion fc-scrollgrid-shrink-cushion fc-scrollgrid-sync-inner">all-day</span></div></td><td role="gridcell" data-date="2024-07-14" class="fc-day fc-day-sun fc-day-past fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td><td role="gridcell" data-date="2024-07-15" class="fc-day fc-day-mon fc-day-past fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td><td role="gridcell" data-date="2024-07-16" class="fc-day fc-day-tue fc-day-past fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td><td role="gridcell" data-date="2024-07-17" class="fc-day fc-day-wed fc-day-past fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td><td role="gridcell" data-date="2024-07-18" class="fc-day fc-day-thu fc-day-past fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td><td role="gridcell" data-date="2024-07-19" class="fc-day fc-day-fri fc-day-today fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td><td role="gridcell" data-date="2024-07-20" class="fc-day fc-day-sat fc-day-future fc-daygrid-day"><div class="fc-daygrid-day-frame fc-scrollgrid-sync-inner"><div class="fc-daygrid-day-events"><div class="fc-daygrid-day-bottom" style="margin-top: 0px;"></div></div><div class="fc-daygrid-day-bg"></div></div></td></tr></tbody></table></div></div></div></td></tr><tr role="presentation" class="fc-scrollgrid-section"><td class="fc-timegrid-divider fc-cell-shaded"></td></tr><tr role="presentation" class="fc-scrollgrid-section fc-scrollgrid-section-body  fc-scrollgrid-section-liquid"><td role="presentation"><div class="fc-scroller-harness fc-scroller-harness-liquid"><div class="fc-scroller fc-scroller-liquid-absolute" style="overflow: hidden scroll;"><div class="fc-timegrid-body" style="width: 703px;"><div class="fc-timegrid-slots"><table aria-hidden="true" class="" style="width: 703px;"><colgroup><col style="width: 54px;"></colgroup><tbody><tr><td data-time="00:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">12am</div></div></td><td data-time="00:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="00:30:00"></td><td data-time="00:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="01:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">1am</div></div></td><td data-time="01:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="01:30:00"></td><td data-time="01:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="02:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">2am</div></div></td><td data-time="02:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="02:30:00"></td><td data-time="02:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="03:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">3am</div></div></td><td data-time="03:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="03:30:00"></td><td data-time="03:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="04:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">4am</div></div></td><td data-time="04:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="04:30:00"></td><td data-time="04:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="05:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">5am</div></div></td><td data-time="05:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="05:30:00"></td><td data-time="05:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="06:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">6am</div></div></td><td data-time="06:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="06:30:00"></td><td data-time="06:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="07:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">7am</div></div></td><td data-time="07:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="07:30:00"></td><td data-time="07:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="08:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">8am</div></div></td><td data-time="08:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="08:30:00"></td><td data-time="08:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="09:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">9am</div></div></td><td data-time="09:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="09:30:00"></td><td data-time="09:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="10:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">10am</div></div></td><td data-time="10:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="10:30:00"></td><td data-time="10:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="11:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">11am</div></div></td><td data-time="11:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="11:30:00"></td><td data-time="11:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="12:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">12pm</div></div></td><td data-time="12:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="12:30:00"></td><td data-time="12:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="13:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">1pm</div></div></td><td data-time="13:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="13:30:00"></td><td data-time="13:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="14:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">2pm</div></div></td><td data-time="14:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="14:30:00"></td><td data-time="14:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="15:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">3pm</div></div></td><td data-time="15:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="15:30:00"></td><td data-time="15:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="16:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">4pm</div></div></td><td data-time="16:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="16:30:00"></td><td data-time="16:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="17:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">5pm</div></div></td><td data-time="17:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="17:30:00"></td><td data-time="17:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="18:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">6pm</div></div></td><td data-time="18:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="18:30:00"></td><td data-time="18:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="19:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">7pm</div></div></td><td data-time="19:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="19:30:00"></td><td data-time="19:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="20:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">8pm</div></div></td><td data-time="20:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="20:30:00"></td><td data-time="20:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="21:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">9pm</div></div></td><td data-time="21:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="21:30:00"></td><td data-time="21:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="22:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">10pm</div></div></td><td data-time="22:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="22:30:00"></td><td data-time="22:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr><tr><td data-time="23:00:00" class="fc-timegrid-slot fc-timegrid-slot-label fc-scrollgrid-shrink"><div class="fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"><div class="fc-timegrid-slot-label-cushion fc-scrollgrid-shrink-cushion">11pm</div></div></td><td data-time="23:00:00" class="fc-timegrid-slot fc-timegrid-slot-lane"></td></tr><tr><td class="fc-timegrid-slot fc-timegrid-slot-label fc-timegrid-slot-minor" data-time="23:30:00"></td><td data-time="23:30:00" class="fc-timegrid-slot fc-timegrid-slot-lane fc-timegrid-slot-minor"></td></tr></tbody></table></div><div class="fc-timegrid-cols"><table role="presentation" style="width: 703px;"><colgroup><col style="width: 54px;"></colgroup><tbody role="presentation"><tr role="row"><td aria-hidden="true" class="fc-timegrid-col fc-timegrid-axis"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-14" class="fc-day fc-day-sun fc-day-past fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 0px 0% -1039px; z-index: 1;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-start fc-event-past bg-warning fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-time">12:00</div><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Long Event</div></div></div></div></a></div></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-15" class="fc-day fc-day-mon fc-day-past fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 0px 0% -1039px; z-index: 1;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-past bg-warning fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Long Event</div></div></div></div></a></div></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-16" class="fc-day fc-day-tue fc-day-past fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 0px 0% -1039px; z-index: 1;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-resizable fc-event-end fc-event-past bg-warning fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-time">12:00</div><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Long Event</div></div></div></div><div class="fc-event-resizer fc-event-resizer-end"></div></a></div><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 693px 0% -736px 50%; z-index: 2;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-past bg-info fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-time">4:00</div><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Repeating Event</div></div></div></div><div class="fc-event-resizer fc-event-resizer-end"></div></a></div></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-17" class="fc-day fc-day-wed fc-day-past fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-18" class="fc-day fc-day-thu fc-day-past fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-19" class="fc-day fc-day-fri fc-day-today fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 455px 0% -498px; z-index: 1;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future bg-success fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-time">10:30</div><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Meeting</div></div></div></div><div class="fc-event-resizer fc-event-resizer-end"></div></a></div><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 520px 0% -606px; z-index: 1;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-today fc-event-future bg-danger fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-time">12:00 - 2:00</div><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Lunch</div></div></div></div><div class="fc-event-resizer fc-event-resizer-end"></div></a></div></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td><td role="gridcell" data-date="2024-07-20" class="fc-day fc-day-sat fc-day-future fc-timegrid-col"><div class="fc-timegrid-col-frame"><div class="fc-timegrid-col-bg"></div><div class="fc-timegrid-col-events"><div class="fc-timegrid-event-harness fc-timegrid-event-harness-inset" style="inset: 823px 0% -975px; z-index: 1;"><a tabindex="0" class="fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-future bg-success fc-timegrid-event fc-v-event"><div class="fc-event-main"><div class="fc-event-main-frame"><div class="fc-event-time">7:00 - 10:30</div><div class="fc-event-title-container"><div class="fc-event-title fc-sticky">Birthday Party</div></div></div></div><div class="fc-event-resizer fc-event-resizer-end"></div></a></div></div><div class="fc-timegrid-col-events"></div><div class="fc-timegrid-now-indicator-container"></div></div></td></tr></tbody></table></div></div></div></div></td></tr></tbody></table></div></div></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="contact" role="tabpanel">
                                    <h5 class="font-size-14 mb-2">Dosyalar</h5>

                                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                        <tr>
                                            <th>Dosya Adı</th>
                                            <th>Eklenme Tarihi</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><i class="mdi mdi-file-document font-size-16 align-middle text-primary me-2"></i> Dosya Adı</td>
                                            <td>01.01.2020</td>
                                        </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card body -->
                </div>
                <!-- end card -->
            </div>
            <!-- end col -->
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
        <script>
            $(document).ready(function() {
                $('.js-example-basic-single').select2();
            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\staj\resources\views/panel/proje/details.blade.php ENDPATH**/ ?>