<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-select-bs4/css//select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('add-ticket')); ?>"><button  class="btn btn-success" id="btn-save-event">Ticket Olustur</button></a>
                    </div>
                    <div class="card-body">

                        <h4 class="card-title">Kullanici Ticketlari</h4>
                        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>Ticket Adı</th>
                                <th>Ticket Sahibi</th>
                                <th>Kategori</th>
                                <th>Etiketler</th>
                                <th>Çözüldü Mü</th>
                                <th>Kilitli Mi</th>
                                <th>Açılma Tarihi</th>
                                <th>Güncellenme Tarihi</th>
                                <th>Öncelik</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($t->title); ?></td>
                                    <td><?php echo e($t->user->name); ?> - ID : <?php echo e($t->user->id); ?></td>
                                    <td><?php $__currentLoopData = $t->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($c->name); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                    <td><?php $__currentLoopData = $t->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge py-1 rounded-pill bg-info"><?php echo e($l->name); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                    <td><?php if($t->is_resolved=='1'): ?> <span class="badge font-size-14  text-black badge-soft-success"><i class="ri-checkbox-circle-fill "></i> Evet</span> <?php else: ?> <span class="font-size-14 badge badge-soft-danger"><i class="ri-close-circle-fill"></i> Hayir</span> <?php endif; ?></td>
                                    <td><?php if($t->is_locked=='1'): ?> <span class="badge font-size-14 font-size-13 text-black badge-soft-success"><i class="ri-lock-line"></i> Evet</span> <?php else: ?> <span class="badge font-size-14 badge-soft-danger"><i class="ri-lock-unlock-line "></i>Hayir</span> <?php endif; ?></td>
                                    <td><?php echo e($t->created_at); ?></td>
                                    <td><?php echo e($t->updated_at); ?></td>
                                    <td><span style="background: <?php if($t->priority == '1'): ?> #780000 <?php elseif($t->priority == '2'): ?> #c1121f <?php elseif($t->priority == 3): ?> #fdf0d5; color: black <?php elseif($t->priority == '4'): ?> #003049 <?php elseif($t->priority == '5'): ?> #669bbc  <?php endif; ?> " class="badge font-size-14 rounded-pill float-end"><?php echo e($t->priority); ?></span></td>
                                    <td> <span class="badge rounded-pill <?php if($t->status == 'Okunmadı'): ?>bg-danger <?php elseif($t->status == 'Okundu'): ?> bg-secondary  <?php elseif($t->status == 'Cevaplandı'): ?> bg-info <?php elseif($t->status == 'Kapandı'): ?> bg-success <?php endif; ?> float-end"><?php echo e($t->status); ?></span> </td>
                                    <td>
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a href="<?php echo e(url('Panel/edit-ticket').'/'.$t->uuid); ?>" class="px-2 text-primary"><i
                                                        class="ri-pencil-line font-size-18"></i></a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a href="<?php echo e(url('delete-ticket').'/'.$t->uuid); ?>" class="px-2 text-danger"><i
                                                        class="ri-delete-bin-line font-size-18"></i></a>
                                            </li>
                                            <li class="list-inline-item dropdown">
                                                <a class="dropdown-toggle font-size-18 px-2" href="#"
                                                   role="button" data-bs-toggle="dropdown" aria-haspopup="true">
                                                    <i class="ri-more-2-fill"></i>
                                                </a>

                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <?php if($t->status == 'Okunmadı'): ?><a class="dropdown-item" href="<?php echo e(url('Panel/Ticket-Answer').'/'.$t->uuid); ?>">Cevapla</a><?php endif; ?>
                                                    <?php if($t->status == 'Cevaplandı'): ?><a class="dropdown-item" href="<?php echo e(url('Panel/Ticket-Answer-History').'/'.$t->uuid); ?>">Mesaj Detaylari</a><?php endif; ?>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->







    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- Required datatable js -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <!-- Buttons examples -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/jszip/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>

        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-select/js/dataTables.select.min.js')); ?>"></script>

        <!-- Responsive examples -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>

        <!-- Datatable init js -->
        <script src="<?php echo e(URL::asset('public/build/js/pages/datatables.init.js')); ?>"></script>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/panel/tickets/index.blade.php ENDPATH**/ ?>