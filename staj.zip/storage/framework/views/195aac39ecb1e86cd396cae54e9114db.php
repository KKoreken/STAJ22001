<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('addBlog')); ?>"><button  class="btn btn-success" id="btn-save-event">Yeni Ekle</button></a>
                    </div>
                    <div class="card-body">
                        <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>Başlık</th>
                                <th>Kategori</th>
                                <th>Eklenme Tarihi</th>
                                <th>İşlem</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i->baslik); ?></td>
                                <td><?php echo e($i->category[0]->name); ?></td>
                                <td><?php echo e($i->created_at); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <a class="text-muted dropdown-toggle font-size-20" role="button"
                                           data-bs-toggle="dropdown" aria-haspopup="true">
                                            <i class="mdi mdi-dots-vertical"></i>
                                        </a>

                                        <div class="dropdown-menu dropdown-menu-end">
                                            <a class="dropdown-item" href="<?php echo e(url('Panel/Ilgi-Alani-Duzenle/')); ?>/<?php echo e($i->id); ?>"><i class="mdi mdi-pencil"></i> Düzenle</a>
                                            <a class="dropdown-item" href="<?php echo e(url('Panel/Ilgi-Alani-Sil/')); ?>/<?php echo e($i->id); ?>"><i class="mdi mdi-delete"></i> Sil</a>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-select-bs4/css//select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Responsive datatable examples -->
        <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <!-- Buttons examples -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/jszip/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>

        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-select/js/dataTables.select.min.js')); ?>"></script>

        <!-- Responsive examples -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>

        <!-- Datatable init js -->
        <script src="<?php echo e(URL::asset('public/build/js/pages/datatables.init.js')); ?>"></script>
    <?php echo $__env->make('includes.js.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kk\resources\views/panel/blog/index.blade.php ENDPATH**/ ?>