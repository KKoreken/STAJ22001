<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('kk/public/build/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('kk/public/build/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('kk/public/build/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('kk/public/build/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('kk/public/build/libs/node-waves/waves.min.js')); ?>"></script>
<!-- Icon -->
<script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH C:\xampp\htdocs\staj\resources\views/layouts/vendor-scripts.blade.php ENDPATH**/ ?>