<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ilgi Alanlari</h5>

                        <form action="<?php echo e(route('editInterestPost')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>" >
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input value="<?php echo e($item->text); ?>" type="text" class="form-control" name="text" id="floatingFirstnameInput"
                                               placeholder="Enter Your First Name">
                                        <label for="floatingFirstnameInput">Metin</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-lg-6"><div class="my-3">
                                        <label for="customFile"><h5 class="card-title">Logo</h5></label>
                                        <input placeholder='&#xf02b;' name="logo" type="file" class="form-control" id="customFile">
                                    </div></div>
                                <div class="col-md-12 col-lg-6 pt-3">
                                    <h5 class="card-title">Mevcut Logo</h5>
                                    <img src="<?php echo e(url('storage/app/'.$item->logo)); ?>"  style="height: 30px; margin-top: 10px" /></div>

                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Submit</button>
                                </div>
                        </form>
                    </div>
                    <!-- end card body -->
                </div>
                <!-- end card -->
            </div>
            <!-- end col -->
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\resources\views/panel/ilgialanlari/edit.blade.php ENDPATH**/ ?>