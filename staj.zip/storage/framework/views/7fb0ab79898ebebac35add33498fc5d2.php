<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        user girisi
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('build/js/app.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/index.blade.php ENDPATH**/ ?>