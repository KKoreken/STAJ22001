<link rel="stylesheet" href="<?=url('/')?>/resources/css/iziToast.min.css">
<script src="<?=url('/')?>/resources/js/iziToast.min.js" type="text/javascript"></script>
<script>
    <?php if(Session::has('error')): ?>
    iziToast.error({
        title: 'Hata',
        message: '<?php echo e(Session::get('error')); ?>',
    });
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
    iziToast.success({
        title: 'İşlem Başarılı',
        message: '<?php echo e(Session::get('success')); ?>',
    });
    <?php endif; ?>
</script>
<?php /**PATH /home/koreken1/public_html/resources/views/includes/js/toastr.blade.php ENDPATH**/ ?>