<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ilgi Alanlari</h5>

                        <form action="<?php echo e(route('addFilePost')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" name="text" id="floatingFirstnameInput"
                                               placeholder="Enter Your First Name">
                                        <label for="floatingFirstnameInput">Metin</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">


                            <div class="my-3">
                                <label for="customFile"><h5 class="card-title">Fotograf</h5></label>
                                <input accept="image/png, image/gif, image/jpeg"  placeholder='&#xf02b;' name="foto" type="file" class="form-control" id="customFile">
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary w-md">Onayla</button>
                            </div>
                        </form>
                    </div>
                    <!-- end card body -->
                </div>
                <!-- end card -->
            </div>
            <!-- end col -->
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\resources\views/panel/filemanager/add.blade.php ENDPATH**/ ?>