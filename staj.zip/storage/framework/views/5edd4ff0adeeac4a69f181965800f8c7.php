<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>"
          rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>"
          rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-select-bs4/css//select.bootstrap4.min.css')); ?>"
          rel="stylesheet" type="text/css"/>

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>"
          rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('add-ticket')); ?>">
                            <button class="btn btn-success" id="btn-save-event">Ticket Olustur</button>
                        </a>
                    </div>
                    <div class="card-body">

                        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>Kategori Adı</th>
                                <th>Post Sayısı</th>
                                <th>Durumu</th>
                                <th>İşlem</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($c->name); ?></td>
                                    <td><?php echo e($c->posts_count); ?></td>
                                    <td><?php if($c->is_visible=='1'): ?>
                                            <span class="badge font-size-14  text-black badge-soft-success"> Aktif </span>
                                        <?php else: ?>
                                            <span class="font-size-14 badge badge-soft-danger"> Pasif</span>
                                        <?php endif; ?></td>
                                    <td>
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a href="<?php echo e(url('Panel/Edit-Category').'index.blade.php/'.$c->id); ?>"
                                                   class="px-2 text-primary"><i
                                                            class="ri-pencil-line font-size-18"></i></a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a href="<?php echo e(url('Panel/Delete-Category').'index.blade.php/'.$c->id); ?>"
                                                   class="px-2 text-danger"><i
                                                            class="ri-delete-bin-line font-size-18"></i></a>
                                            </li>
                                            <li class="list-inline-item dropdown">
                                                <a class="dropdown-toggle font-size-18 px-2" href="#"
                                                   role="button" data-bs-toggle="dropdown" aria-haspopup="true">
                                                    <i class="ri-more-2-fill"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(url('Panel/Review-Category-Tickets').'index.blade.php/'.$c->id); ?>">Ticketları
                                                        Gör</a>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- Required datatable js -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <!-- Buttons examples -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/jszip/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>

        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-select/js/dataTables.select.min.js')); ?>"></script>

        <!-- Responsive examples -->
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('public/build/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>

        <!-- Datatable init js -->
        <script src="<?php echo e(URL::asset('public/build/js/pages/datatables.init.js')); ?>"></script>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\staj\resources\views/panel/categories/index.blade.php ENDPATH**/ ?>