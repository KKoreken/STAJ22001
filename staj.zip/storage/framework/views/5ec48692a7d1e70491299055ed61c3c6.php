<?php $__env->startSection('title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Yönetici Paneli
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <body data-sidebar="colored">

    <?php $__env->stopSection(); ?>
    <?php echo $__env->make('layouts.usertopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startSection('content'); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
        <!-- App js -->
        <script src="<?php echo e(URL::asset('public/build/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-without-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koreken1/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>