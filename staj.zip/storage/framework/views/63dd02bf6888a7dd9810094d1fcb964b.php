<div>
    <h1>Tickets</h1>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($ticket->title); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>

    <button wire:click="loadMore">Load More</button>
</div>
<?php /**PATH /home/koreken1/public_html/resources/views/livewire/tickets.blade.php ENDPATH**/ ?>