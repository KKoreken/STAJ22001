<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="<?php echo e(route('panel')); ?>" class="logo logo-dark">
            <span class="logo-sm">
                <img src="<?php echo e(URL::asset('public/img/logo.png')); ?>" alt="logo-sm-dark" height="24">
            </span>
            <span class="logo-lg">
                <img src="<?php echo e(URL::asset('public/img/logo.png')); ?>" alt="logo-dark" height="22">
            </span>
        </a>

        <a href="<?php echo e(route('panel')); ?>" class="logo logo-light">
            <span class="logo-sm">
                <img src="<?php echo e(URL::asset('public/img/logo.png')); ?>" alt="logo-sm-light" height="24">
            </span>
            <span class="logo-lg">
                <img src="<?php echo e(URL::asset('public/img/logo.png')); ?>" alt="logo-light" height="22">
            </span>
        </a>
    </div>

    <button type="button" class="btn btn-sm px-3 font-size-24 header-item waves-effect vertical-menu-btn"
        id="vertical-menu-btn">
        <i class="mdi mdi-align-horizontal-left"></i>
    </button>

    <div data-simplebar class="vertical-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li>
                    <a href="<?php echo e(route('panel')); ?>" class="waves-effect">
                        <i class="uim uim-airplay"></i>
                        <span>Yönetici Paneli</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('panel')); ?>" class="waves-effect">
                        <i class="uim uim-airplay"></i>
                        <span>Mesajlar</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('panel')); ?>" class="waves-effect">
                        <i class="uim uim-airplay"></i>
                        <span>İş Alanları</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('Panel/Ilgi-Alanlari')); ?>" class="waves-effect">
                        <i class="uim uim-airplay"></i>
                        <span>İlgi Alanları</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('panel-social-medias')); ?>" class="waves-effect">
                        <i class="uim uim-airplay"></i>
                        <span>Sosyal Medya Hesapları</span>
                    </a>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uim uim-layers-alt"></i>
                        <span>Blog Postları</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li><a href="<?php echo e(route('getblog')); ?>">
                        <span>Postlar</span></a></li>
                        <li><a href="javascript: void(0);" class="has-arrow">Ayarlar</a>
                            <ul class="sub-menu" aria-expanded="true">
                                <li><a href="<?php echo e(route('getcategories')); ?>">Kategoriler</a></li>
                                <li><a href="<?php echo e(route('panel-ticket-options-labels')); ?>">Etiketler</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uim uim-layers-alt"></i>
                        <span>Projeler</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li><a href="<?php echo e(route('getProjectsPanel')); ?>">
                        <span>Projeler</span></a></li>
                        <li><a href="javascript: void(0);" class="has-arrow">Projeler</a>
                            <ul class="sub-menu" aria-expanded="true">
                                <li><a href="<?php echo e(url('Panel/Proje/Kategoriler')); ?>">Kategoriler</a></li>
                                <li><a href="<?php echo e(route('getProjectLabels')); ?>">Etiketler</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uim uim-layers-alt"></i>
                        <span>Sertifikalar</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li><a href="<?php echo e(url('Panel/Tickets')); ?>">
                        <span>Ticketlar</span></a></li>
                        <li><a href="javascript: void(0);" class="has-arrow">Ayarlar</a>
                            <ul class="sub-menu" aria-expanded="true">
                                <li><a href="<?php echo e(route('panel-ticket-options-categories')); ?>">Kategoriler</a></li>
                                <li><a href="<?php echo e(route('panel-ticket-options-labels')); ?>">Etiketler</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>

        </div>
        <!-- Sidebar -->
    </div>

    <div class="dropdown px-3 sidebar-user sidebar-user-info">
        <button type="button" class="btn w-100 px-0 border-0" id="page-header-user-dropdown"
            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <img src="<?php echo e(URL::asset('public/build/images/users/avatar-2.jpg')); ?>"
                        class="img-fluid header-profile-user rounded-circle" alt="">
                </div>

                <div class="flex-grow-1 ms-2 text-start">
                    <span class="ms-1 fw-medium user-name-text"><?php echo e(Auth::user()->name); ?></span>
                </div>

                <div class="flex-shrink-0 text-end">
                    <i class="mdi mdi-dots-vertical font-size-16"></i>
                </div>
            </span>
        </button>
        <div class="dropdown-menu dropdown-menu-end">
            <!-- item-->
            <a class="dropdown-item" href="javascript:void(0)"><i
                    class="mdi mdi-account-circle text-muted font-size-16 align-middle me-1"></i> <span
                    class="align-middle">Profilimi Gör</span></a>
            <a class="dropdown-item" href="javascript:void();"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                    class="mdi mdi-lock text-muted font-size-16 align-middle me-1"></i> <span
                    class="align-middle">Çıkış Yap</span></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\xampp\htdocs\kk\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>