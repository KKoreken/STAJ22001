<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h4>Deneme sayfası</h4>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\kk\resources\views/layouts/footer.blade.php ENDPATH**/ ?>