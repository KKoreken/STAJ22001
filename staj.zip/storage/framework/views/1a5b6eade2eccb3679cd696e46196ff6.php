<!-- Layout config Js -->
<script src="<?php echo e(URL::asset('public/build/js/layout.js')); ?>"></script>
<?php echo $__env->yieldContent('css'); ?>
<!-- Bootstrap Css -->
<link href="<?php echo e(URL::asset('public/build/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(URL::asset('public/build/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(URL::asset('public/build/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
<?php /**PATH D:\xampp\htdocs\resources\views/layouts/head-css.blade.php ENDPATH**/ ?>